# 1º Comando: npx create-react-app nomedoprojeto template 
# 2º Public fica o html que carrega tudo
# 3º src fica os códigos do servidor
# 4º cada componente é um arquivo.tsx
# 5º Todo arquivo(file) que é componentes deve começar com letra maiúsculas
# 6º A função em javascript é um component
# 7º Todo componente retorna HTML
# 8º Quando tiver mais de um elemento html dentro do return esse deve conter uma fragmentação <></> ou um div
# 9º No package.json ficam todas as dependencias
# 10º Chamada de componente é estilo tag: <Home/>
# 11º O index.html é mapeado pelo o index.tx que carrega App.tsx
