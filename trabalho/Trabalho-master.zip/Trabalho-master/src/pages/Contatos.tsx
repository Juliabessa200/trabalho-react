import { Footer } from "../components/Footer"

    export const Contatos = () => {
    return (
        <>
            <main>

                <Footer/>
            </main>
            
        </>
    )
}